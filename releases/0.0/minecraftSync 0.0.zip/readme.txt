To run the application, simply double-click on the *setup* executable. 

If you have any questions or comments, please feel free to visit: 
https://github.com/makccr/minecraftSync

If the program fails to start, you might try this: 
1. Drag *setup* to the desktop. 
2. Open Terminal. 
3. chmod +x ~/Desktop/setup
4. Double-click on the file to try again. 
